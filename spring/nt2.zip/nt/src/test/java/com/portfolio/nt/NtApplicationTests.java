package com.portfolio.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NtApplicationTests {

	@Test
	void contextLoads() {
	}

}
