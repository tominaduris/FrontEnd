package com.portfolio.naduristomas.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NtApplication {

	public static void main(String[] args) {
		SpringApplication.run(NtApplication.class, args);
	}

}
